=== Network Merchants Inc Gateway for WooCommerce ===
Contributors: robustsoftech
Tags: payment, gateway, nmi, credit card, woocommerce
Requires at least: 4.5
Tested up to: 6.8.2
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Accept secure credit card payments through Network Merchants Inc Gateway.

== Description ==

Network Merchants Inc Gateway for WooCommerce is a secure payment solution that allows your customers to pay using credit cards through the Network Merchants Inc (NMI) payment gateway.

Developed by Robust Softech Private Limited - A complete credit card payment solution for modern e-commerce.

= Key Features =

* **Credit Card Processing** - Secure credit card payments with Collect.js tokenization
* **Tokenization** - Save customer payment methods for future use
* **Subscription Support** - Full WooCommerce Subscriptions integration
* **Refund Support** - Process refunds directly from WooCommerce
* **HPOS Compatible** - Works with WooCommerce High-Performance Order Storage
* **WooCommerce Blocks** - Compatible with the new block-based checkout
* **Environment Switching** - Production/Sandbox environments
* **Debug Logging** - Comprehensive logging for troubleshooting

= Security Features =

* **Collect.js Integration** - Most secure payment method (default)
* **PCI DSS Compliant** - Through NMI's secure processing
* **Tokenization** - Secure card storage
* **SSL Encryption** - All transactions encrypted

= Easy Setup =

1. Install and activate the plugin
2. Enter your NMI API credentials (Private Security Key + Public Key)
3. Choose your environment (Production/Sandbox)
4. Start accepting credit card payments!

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/network-merchants-inc-gateway-for-woocommerce` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to WooCommerce > Settings > Payments
4. Find "NMI Payment Gateway Pro for WooCommerce" and click "Set up"
5. Enter your NMI API credentials and configure settings
6. Save changes and test payments

== Configuration ==

### Required Settings

* **Enable/Disable**: Turn the gateway on/off
* **Title**: Payment method name shown to customers
* **Description**: Payment method description
* **Environment**: Choose Production or Sandbox
* **Private Security Key**: Your NMI Private Security Key
* **Public Key**: Your NMI Public Key for tokenization

### Optional Settings

* **Payment API Method**: Choose between Collect.js (recommended) or Direct Post
* **Transaction Type**: Sale (authorize & capture) or Authorize Only
* **Accepted Cards**: Select which card types to accept
* **Debug Log**: Enable logging for troubleshooting

== Testing ==

### Sandbox Testing

1. Set Environment to "Sandbox"
2. Use test card numbers:
   - Visa: 4111111111111111
   - Mastercard: 5555555555554444
   - American Express: 378282246310005
3. Use any future expiry date and any 3-digit CVV
4. Test successful and failed transactions

### Production Setup

1. Set Environment to "Production"
2. Enter your live NMI credentials
3. Test with small amounts first
4. Monitor debug logs for any issues

== Troubleshooting ==

### Common Issues

**Payment method not showing on checkout:**
- Check if gateway is enabled
- Verify API keys are entered correctly
- Ensure WooCommerce is active

**Payment fails with "Invalid credentials":**
- Verify Private Security Key is correct
- Check if Public Key is properly set
- Ensure environment matches your credentials

**Collect.js fields not loading:**
- Check browser console for JavaScript errors
- Verify Public Key is valid
- Ensure SSL certificate is active

### Debug Logging

Enable debug logging in plugin settings to troubleshoot issues:
1. Go to WooCommerce > Settings > Payments
2. Click "Set up" on NMI gateway
3. Enable "Debug log"
4. Check logs at: WooCommerce > Status > Logs

== Support ==

For support and documentation, visit: https://www.robustsoftech.com/

== Changelog ==

= 1.0.1 =
* Initial release
* Credit card processing via Collect.js
* Tokenization support
* WooCommerce HPOS compatibility
* Subscription support
* Refund processing
* Debug logging

== Frequently Asked Questions ==

= Do I need an NMI merchant account? =

Yes, you need an active NMI merchant account to use this plugin.

= Is this plugin PCI compliant? =

Yes, this plugin is PCI compliant through NMI's Collect.js secure payment processing.

= Does this plugin support subscriptions? =

Yes, the plugin fully supports WooCommerce Subscriptions.

= Can I process refunds? =

Yes, you can process refunds directly from the WooCommerce order page.

= What are the required API keys? =

Only 2 keys are required:
1. Private Security Key
2. Public Key

== Screenshots ==

1. Payment gateway settings page with only 2 keys required
2. Checkout page with payment options
3. Order management with transaction details

== Changelog ==

= 1.0.0 =
* Initial release
* Credit card processing with Collect.js tokenization
* Only 2 API keys required (Private Security Key + Public Key)
* Subscription support
* HPOS compatibility
* WooCommerce Blocks integration
* Refund support
* Debug logging

== Upgrade Notice ==

= 1.0.0 =
Initial release of the Network Merchants Inc Gateway for WooCommerce with Collect.js security and simplified 2-key setup.
