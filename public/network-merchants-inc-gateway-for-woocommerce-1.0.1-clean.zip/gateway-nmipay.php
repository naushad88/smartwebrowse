<?php
/**
 * Plugin Name: Network Merchants Inc Gateway for WooCommerce
 * Plugin URI: https://www.robustsoftech.com/
 * Description: Accept secure credit card payments on your WooCommerce store with the Network Merchants Inc (NMI) Payment Gateway.
 * Version: 1.0.1
 * Author: Robust Softech Private Limited
 * Author URI: https://www.robustsoftech.com
 * Contributors: robustsoftech
 * Requires at least: 4.5
 * Tested up to: 6.8.2
 * WC requires at least: 9.0.0
 * WC tested up to: 10.0.4
 * WC HPOS Compatible: yes
 * Requires PHP: 7.4
 *
 * Text Domain: woo-nmi-robust
 * Domain Path: /lang/
 *
 * @author Robust Softech Private Limited
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'plugins_loaded', 'init_woocommerce_nmipay', 0 );

function init_woocommerce_nmipay() {
	if ( ! class_exists( 'WC_Payment_Gateway_CC' ) || ! class_exists( 'WC_Payment_Gateway' ) ) {
		return;
	}

	load_plugin_textdomain( 'woo-nmi-robust', false, dirname( plugin_basename( __FILE__ ) ) . '/lang' );

	include 'includes/cc.php';

	/**
	 * Add the gateway to WooCommerce.
	 **/
	function add_nmipay_gateway( $methods ) {
		if ( class_exists( 'woocommerce_nmipay' ) ) {
			$methods[] = 'woocommerce_nmipay';
		}
		return $methods;
	}
	add_filter( 'woocommerce_payment_gateways', 'add_nmipay_gateway' );
	
	// Add settings link to plugins page
	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'nmi_add_action_links' );
}

/**
 * Add action links to plugins page
 */
function nmi_add_action_links( $links ) {
	$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=wc-settings&tab=checkout&section=woocommerce_nmipay' ) ) . '">Settings</a>';
	array_unshift( $links, $settings_link );
	return $links;
}

// Declare HPOS compatibility
add_action( 'before_woocommerce_init', function() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
});
